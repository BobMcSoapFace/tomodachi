C:\Users\riley\AppData\Local\arduino\sketches\A0734598BF2B286803FF8432B634F5EC\libraries\Adafruit_GFX_Library\glcdfont.c.o: \
 c:\Users\riley\Projects\libraries\Adafruit_GFX_Library\glcdfont.c
